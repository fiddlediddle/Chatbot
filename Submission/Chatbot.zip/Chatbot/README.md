An adaptation of Eliza by Joe Strout created by Seal Team 6 Part 2: Electric Boogaloo

TODO [
Finalize reformatting of responses and triggers;
Clean up code (format spaces to tabs);
Remove extra whitespace;
]
